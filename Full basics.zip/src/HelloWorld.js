import React from "react";

class HelloWorld extends React.Component {
    render() {
        var myStyle = {
            fontSize: 80,
            fontFamily: 'Courier',
            color: '#003300'
        }
        return (
            <div>
                <h1>Hello World!</h1>
                <p>Welocome to carrer shaper</p>
                <div>
                    <h1 className="hello" >JSX Attributes</h1>
                    <p data-customAttribute="demo">custom attribute data-custom Attribute </p>
                    <h1 className="expression" >{25 + 20}</h1>
                    {/* This is a comment in JSX */}
                    <h1 style={myStyle}>Using styling in jsx</h1>
                </div>
            </div>
        );
    }
}
export default HelloWorld;