

import React, { Component } from 'react';
import ChildComponent from './ChildComponent';
import ParentComponent from './ParentComponent';


function PropsDemo() {
    return (
        <div className="App">
            <h1>-----------DEMO PROPS-------------</h1>
            <ParentComponent />

        </div>
    );
}


export default PropsDemo;
