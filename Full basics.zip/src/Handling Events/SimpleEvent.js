import React from 'react';

function SimpleEvent() {
    function eventHandler() {
        alert('React Event Handling Demo');
    }


    return (
        <div className='App'>
            <h1>React Event Handling</h1>
            <button onClick={eventHandler}>Click for alert!</button>
        </div>
    );
}

export default SimpleEvent;
