import React from 'react';
import ReactDOM from 'react-dom/client';

export default class HcomponentDidUpdate extends React.Component {
    constructor(props) {
        super(props);
        this.state = { favoritefood: "Nan with paneer tika" };
    }
    componentDidMount() {
        setTimeout(() => {
            this.setState({ favoritefood: "Egg Fried Rice" })
        }, 1000)
    }
    componentDidUpdate() {
        document.getElementById("mydiv").innerHTML =
            "The updated favorite is " + this.state.favoritefood;
    }
    render() {
        return (
            <div>
                <h1>My Favorite Food is {this.state.favoritefood}</h1>
                <div id="mydiv"></div>
            </div>
        );
    }
}

// <HcomponentDidUpdate />


