
import React from 'react';
import ReactDOM from 'react-dom/client';

export default class HgetDerivedStateFromProps extends React.Component {
    constructor(props) {
        super(props);
        this.state = { favoritefood: "momos" };
    }
    static getDerivedStateFromProps(props, state) {
        return { favoritefood: props.favfod };
    }
    changeFood = () => {
        this.setState({ favoritecolor: "sandveg" });
    }
    render() {
        return (
            <div>
                <h1>My Favorite Food is {this.state.favoritefood}</h1>
                <button type="button" onClick={this.changeFood}>Change Food</button>
            </div>
        );
    }
}


//<HgetDerivedStateFromProps favfod="Hotdog" />