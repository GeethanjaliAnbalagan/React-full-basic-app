function MenuItems(props) {
    const item = props.item;
    return <li>Fruit name{item}</li>;
}

export default MenuItems;