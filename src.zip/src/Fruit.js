import React from "react";
import { ReactDOM } from "react-dom/client";

function Fruit(props) {
    return (
        <div>
            <li>
                Fruit name is {props.name};
            </li>
        </div>
    )
}


export default Fruit;