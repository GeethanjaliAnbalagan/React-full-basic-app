import React from 'react';
import ReactDOM from 'react-dom/client';

class StateDemo1 extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            id: 1,
            name: "demo"
        };
    }


    render() {
        return (
            <div>
                <h1>-----------DEMO STATES-------------</h1>
                <h1>The current count is : {this.state.id}</h1>
                <h1>The current name is : {this.state.name}</h1>

            </div>
        );
    }
}

export default StateDemo1;

//How to updTE STATE

this.state.id = "3454";

this.setState({
    id: "111"
});
