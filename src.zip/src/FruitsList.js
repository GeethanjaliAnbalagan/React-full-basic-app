import React from "react";
import { ReactDOM } from "react-dom/client";
import Fruit from "./Fruit";

function FruitsList() {

    const fruits = ['apple', 'orange', 'grapes', 'mango', 'bannana'];
    return (
        <div>
            <h1>List of Fruits</h1>
            <ul>
                {fruits.map((fruit) => <Fruit name={fruit} />)}
            </ul>

        </div>
    );
}

export default FruitsList;