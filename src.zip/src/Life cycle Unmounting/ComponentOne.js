import React from 'react';
export default class ComponentOne extends React.Component {

    // Defining the componentWillUnmount method
    componentWillUnmount() {
        alert('The component is going to be unmounted');
    }

    render() {
        return <h1>Hello, This is Geethanjali Blog</h1>;
    }
}

