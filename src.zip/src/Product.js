import React from "react";

// function Product(props) {
//     return (
//         <div>
//             <h1>Product ID: {props.Pid}</h1>
//             <h1>Product name: {props.Pname}</h1>
//         </div>
//     );
// }

class Product extends React.Component {
    render() {
        return (
            <div>
                <h1>Product ID: {this.props.Pid}</h1>
                <h1>Product name: {this.props.Pname}</h1>
            </div>
        );
    }
}

export default Product;