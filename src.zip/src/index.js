import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import HgetDerivedStateFromProps from './Life cycle updating/HgetDerivedStateFromProps';
import HshouldComponentUpdate from './Life cycle updating/HshouldComponentUpdate';
import HshouldComponentUpdate1 from './Life cycle updating/HshouldComponentUpdate1';
import HgetSnapshotBeforeUpdate from './Life cycle updating/HgetSnapshotBeforeUpdate';
import HcomponentDidUpdate from './Life cycle updating/HcomponentDidUpdate';
import HcomponentWillUnmount from './Life cycle Unmounting/HcomponentWillUnmount';
//geetha
//geetha
/*  */
const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(

  // eslint-disable-next-line react/jsx-no-undef
  <HcomponentWillUnmount />



);

reportWebVitals();
