import React from "react";
import ReactDOM from "react-dom";
import MenuItems from "./MenuItems";

function Navmenu(props) {
    const list = props.menuitems;
    const updatedList = list.map((listItems) => {
        return <MenuItems key={listItems.toString()} item={listItems} />;
    });

    return <ul>{updatedList}</ul>;
}
export default Navmenu;
