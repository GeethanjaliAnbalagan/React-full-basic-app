import React from 'react';
import ReactDOM from 'react-dom/client';

export default class HeadergetDerivedStateFromProps extends React.Component {
    constructor(props) {
        super(props);
        this.state = { favoritefood: "pizza" };
    }
    static getDerivedStateFromProps(props, state) {
        return { favoritefood: props.favfod };
    }
    render() {
        return (
            <h1>My Favorite food is {this.state.favoritefood}</h1>
        );
    }
}


// <HeadergetDerivedStateFromProps favfod="momos" />

