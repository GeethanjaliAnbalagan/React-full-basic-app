import React from 'react';
import ReactDOM from 'react-dom/client';

export default class HeadercomponentDidMount extends React.Component {
    constructor(props) {
        super(props);
        this.state = { favoritefood: "momos" };
    }
    componentDidMount() {
        setTimeout(() => {
            this.setState({ favoritefood: "Potato spring Roll" })
        }, 1000)
    }
    render() {
        return (
            <h1>My Favorite d\food is {this.state.favoritefood}</h1>
        );
    }
}

//<HeadercomponentDidMount />;